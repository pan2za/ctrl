=======================================================
 cliff -- Command Line Interface Formulation Framework
=======================================================

.. image:: https://secure.travis-ci.org/dhellmann/cliff.png?branch=master

cliff is a framework for building command line programs. It uses
setuptools entry points to provide subcommands, output formatters, and
other extensions.

Documentation
=============

Documentation for cliff is hosted on readthedocs.org at http://readthedocs.org/docs/cliff/en/latest/
