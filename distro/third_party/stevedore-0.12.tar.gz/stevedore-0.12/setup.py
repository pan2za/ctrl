#!/usr/bin/env python
import setuptools

setuptools.setup(
    setup_requires=['pbr>=0.5.21,<1.0'],
    pbr=True)
