=====
Tasks
=====

.. automodule:: fabric.tasks
    :members: Task, WrappedCallableTask, execute
